package com.example.appacad;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    private EditText etNome, etEmail, etCelular, etSenha;
    private Spinner spinnerRole;
    private Button btnCadastrar;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        etNome = findViewById(R.id.et_nome_cadastro);
        etEmail = findViewById(R.id.et_email_cadastro);
        etCelular = findViewById(R.id.et_celular_cadastro);
        etSenha = findViewById(R.id.et_senha_cadastro);
        spinnerRole = findViewById(R.id.spinner_role);
        btnCadastrar = findViewById(R.id.btn_cadastrar);

        databaseHelper = new DatabaseHelper(this);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = etNome.getText().toString();
                String email = etEmail.getText().toString();
                String celular = etCelular.getText().toString();
                String senha = etSenha.getText().toString();
                String role = spinnerRole.getSelectedItem().toString();

                if (nome.isEmpty() || email.isEmpty() || celular.isEmpty() || senha.isEmpty()) {
                    Toast.makeText(CadastroActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else if (databaseHelper.isEmailExistente(email)) {
                    Toast.makeText(CadastroActivity.this, "Este e-mail já está cadastrado", Toast.LENGTH_SHORT).show();
                } else {
                    long result = databaseHelper.inserirUsuario(nome, email, celular, senha, role);
                    if (result != -1) {
                        Toast.makeText(CadastroActivity.this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(CadastroActivity.this, "Erro ao cadastrar", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}