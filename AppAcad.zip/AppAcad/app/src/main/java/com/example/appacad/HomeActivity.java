package com.example.appacad;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private TextView tvBemVindo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tvBemVindo = findViewById(R.id.tv_bem_vindo);

        String role = getIntent().getStringExtra("role");
        if (role != null) {
            if (role.equals("Cliente")) {
                tvBemVindo.setText("Bem vindo! Conta Cliente");
            } else if (role.equals("Profissional")) {
                tvBemVindo.setText("Bem vindo! Conta Profissional");
            }
        }
    }
}