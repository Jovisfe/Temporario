package com.example.appacad;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {

    private TextView textViewWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        textViewWelcome = findViewById(R.id.textViewWelcome);

        String tipoUsuario = getIntent().getStringExtra("tipo_usuario");
        if (tipoUsuario != null) {
            if (tipoUsuario.equals("cliente")) {
                textViewWelcome.setText("Bem-vindo! Conta Cliente");
            } else if (tipoUsuario.equals("profissional")) {
                textViewWelcome.setText("Bem-vindo! Conta Profissional");
            }
        }
    }
}