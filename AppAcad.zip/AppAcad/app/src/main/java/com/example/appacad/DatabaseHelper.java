package com.example.appacad;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "appacad.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public String verificarUsuario(String email, String senha) {
        SQLiteDatabase db = this.getReadableDatabase();
        String role = null;
        Cursor cursor = db.rawQuery("SELECT role FROM usuarios WHERE email = ? AND senha = ?", new String[]{email, senha});

        if (cursor != null && cursor.moveToFirst()) {
            role = cursor.getString(0);
        }

        if (cursor != null) {
            cursor.close();
        }

        return role;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE usuarios (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nome TEXT NOT NULL, " +
                "email TEXT NOT NULL UNIQUE, " +
                "celular TEXT NOT NULL, " +
                "senha TEXT NOT NULL, " +
                "role TEXT NOT NULL" +
                ")";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS usuarios");
        onCreate(db);
    }

    public long inserirUsuario(String nome, String email, String celular, String senha, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nome", nome);
        values.put("email", email);
        values.put("celular", celular);
        values.put("senha", senha);
        values.put("role", role);

        long result = db.insert("usuarios", null, values);
        db.close();
        return result;
    }

    public boolean isEmailExistente(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM usuarios WHERE email = ?", new String[]{email});
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        db.close();
        return exists;
    }

    public boolean verificarLogin(String email, String senha) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM usuarios WHERE email = ? AND senha = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email, senha});

        boolean loginValido = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return loginValido;
    }

    public String obterRole(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT role FROM usuarios WHERE email = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email});

        String role = null;
        if (cursor.moveToFirst()) {
            role = cursor.getString(cursor.getColumnIndexOrThrow("role"));
        }
        cursor.close();
        db.close();
        return role;
    }
}